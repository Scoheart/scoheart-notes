function sortArray(nums: number[]): number[] {

};

function BubbleSort(nums: Array<number>) {
    for (let i = 0; i < nums.length; i++) {
        for (let j = i)
    }
}